<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>My Crypto Pool Mirror</title>
<link rel="shortcut icon" href="<?php echo e(asset('images/logo.png')); ?>">

<!--  ==========css link==========  -->
<?php echo $__env->make('frontend.layouts.partials.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\final_project\resources\views/frontend/layouts/partials/head.blade.php ENDPATH**/ ?>