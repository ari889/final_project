<?php $__env->startSection('main-content'); ?>
    <section class="register">
        <!--  ======================== sign in form ======================== -->
        <div class="register-left">
            <div class="top-bar">
                <a href="https://mycryptopoolmirror.com/" class="logo"><img src="<?php echo e(asset('frontend/images/logo.png')); ?>" alt=""></a>
                <div class="dropdown">
                    <button type="button" class="dropdown-button" data-target="lang"><?php if(Session::has('locale')): ?><?php echo e(strtoupper(Session::get('locale'))); ?><?php else: ?> <?php echo e(strtoupper('en')); ?> <?php endif; ?></button>
                    <ul class="dropdown-menu" id="lang">
                        <li class="dropdown-list"><a href="<?php echo e(route('locale', ['locale' => 'en'])); ?>" class="dropdown-link">English</a></li>
                        <li class="dropdown-list"><a href="<?php echo e(route('locale', ['locale' => 'fr'])); ?>" class="dropdown-link">French</a></li>
                    </ul>
                </div>
            </div>
            <div class="register-form" >
                <h1 class="heading"><?php echo app('translator')->get('messages.Sing in here'); ?></h1>
                <form class="register-data" method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="email" placeholder="<?php echo app('translator')->get('messages.Your email'); ?>" value="<?php echo e(old('email')); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong>
                            <?php echo app('translator')->get('messages.'.$message); ?>
                        </strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="password" name="password" placeholder="<?php echo app('translator')->get('messages.Your password'); ?>" autocomplete="current-password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo app('translator')->get('messages.'.$message); ?></strong>
                                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="form-bottom">
                        <p class="login-notice" style="margin-top: 0;"><a href="<?php echo e(route('password.request')); ?>"><?php echo app('translator')->get('messages.Forgot password?'); ?></a></p>
                        <button type="submit" name="register"><?php echo app('translator')->get('messages.Sign In'); ?></button>
                    </div>
                </form>
                <p class="login-notice"><?php echo app('translator')->get('messages.Have no account?'); ?> <a href="https://mycryptopoolmirror.com/"><?php echo app('translator')->get('messages.Sign Up'); ?></a></p>
            </div>
        </div>


        <!--  ======================== live counter ======================== -->
        <div class="register-right">
            <div class="content">
                <q><?php echo app('translator')->get('messages.slogan'); ?></q>

                <div class="counter">

                    <div class="countertext" id="live-register"></div>
                    <p><?php echo app('translator')->get('messages.Members In Countdown'); ?></p>
                </div>
            </div>
        </div>





    </section>
    <?php
    $scripts = ['main', 'liveUserCounter'];
    ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\final_project\resources\views/auth/login.blade.php ENDPATH**/ ?>