<!doctype html>
<html lang="en">
<head>
    <?php echo $__env->make('frontend.layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>

    <?php $__env->startSection('main-content'); ?>
        <?php echo $__env->yieldSection(); ?>

    <?php echo $__env->make('frontend.layouts.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\final_project\resources\views/frontend/layouts/app.blade.php ENDPATH**/ ?>