<script src="<?php echo e(asset('frontend/js/jquery-3.5.1.min.js')); ?>"></script>
<?php $__currentLoopData = $scripts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $script): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <script src="<?php echo e(asset('frontend/js/'.$script.'.js')); ?>"></script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\final_project\resources\views/frontend/layouts/partials/scripts.blade.php ENDPATH**/ ?>