<link rel="stylesheet" href="{{asset('frontend/style.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/all.min.css')}}">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
