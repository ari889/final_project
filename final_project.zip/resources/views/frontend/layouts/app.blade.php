<!doctype html>
<html lang="en">
<head>
    @include('frontend.layouts.partials.head')
</head>
<body>

    @section('main-content')
        @show

    @include('frontend.layouts.partials.scripts')
</body>
</html>
